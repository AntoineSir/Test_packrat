Contribution guidelines are [**here**](https://github.com/Rdatatable/data.table/wiki/Contributing) on the project's wiki :

* so it can be revised easily in one place by anyone
* so that revsions do not trigger Travis and Appveyor checks

